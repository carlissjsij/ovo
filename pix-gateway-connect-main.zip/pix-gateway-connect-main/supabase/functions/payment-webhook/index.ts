import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const payload = await req.json();
    console.log('Webhook received:', payload);

    const { id, status, amount, externalRef } = payload;

    // Send to Utmify
    const UTMIFY_API_TOKEN = Deno.env.get('UTMIFY_API_TOKEN');
    if (UTMIFY_API_TOKEN && status === 'paid') {
      const now = new Date();
      const approvedDate = now.toISOString().replace('T', ' ').slice(0, 19);

      await fetch('https://api.utmify.com.br/api-credentials/orders', {
        method: 'POST',
        headers: {
          'x-api-token': UTMIFY_API_TOKEN,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          orderId: id,
          platform: 'TikTokRewards',
          paymentMethod: 'pix',
          status: 'paid',
          createdAt: approvedDate,
          approvedDate,
          refundedAt: null,
          customer: {
            name: 'Cliente',
            email: 'cliente@email.com',
            phone: '11999999999',
            document: null,
            country: 'BR',
          },
          products: [
            {
              id: 'iof-tax',
              name: 'Imposto IOF',
              planId: null,
              planName: null,
              quantity: 1,
              priceInCents: amount,
            },
          ],
          trackingParameters: {
            src: null,
            sck: null,
            utm_source: null,
            utm_campaign: null,
            utm_medium: null,
            utm_content: null,
            utm_term: null,
          },
          commission: {
            totalPriceInCents: amount,
            gatewayFeeInCents: 0,
            userCommissionInCents: amount,
          },
        }),
      });
    }

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error: unknown) {
    console.error('Webhook error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
