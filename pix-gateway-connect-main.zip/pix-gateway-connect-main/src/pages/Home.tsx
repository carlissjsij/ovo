import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import tiktokLogo from "@/assets/tiktok-logo-white.svg";

const Home = () => {
  const navigate = useNavigate();
  const [showWelcome, setShowWelcome] = useState(true);
  const [onlineCount] = useState(Math.floor(Math.random() * 500) + 1000);
  const [timeLeft, setTimeLeft] = useState(15 * 60); // 15 minutes in seconds

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowWelcome(false);
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (!showWelcome && timeLeft > 0) {
      const interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [showWelcome, timeLeft]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const handleResgate = () => {
    navigate("/quiz");
  };

  if (showWelcome) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center">
        <img src={tiktokLogo} alt="TikTok" className="w-32 h-32 mb-6" />
        <h1 className="text-white text-2xl font-semibold">Bem-vindo ao TikTok</h1>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black flex flex-col">
      {/* Header */}
      <header className="bg-black py-4 flex justify-center">
        <img src={tiktokLogo} alt="TikTok" className="h-8" />
      </header>

      {/* Live Badge */}
      <div className="flex justify-center py-4">
        <div className="bg-red-500 text-white px-4 py-2 rounded-full flex items-center gap-2 text-sm font-medium">
          <span className="w-2 h-2 bg-white rounded-full animate-pulse"></span>
          AO VIVO: {onlineCount.toLocaleString("pt-BR")} pessoas online
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center px-4 pb-8">
        <div className="bg-white rounded-lg w-full max-w-md p-6 shadow-lg">
          <h2 className="text-center text-xl font-semibold text-gray-900 mb-6">
            Sua conta foi validada<br />com sucesso!
          </h2>

          {/* Congratulations Box */}
          <div className="border border-gray-200 rounded-lg p-4 mb-6">
            <p className="text-center">
              <span className="font-semibold">Parabéns</span> 🎉
            </p>
            <p className="text-center text-gray-600 text-sm mt-2">
              Você foi selecionado para participar de uma{" "}
              <span className="font-semibold text-gray-900">Tarefa de Monetização</span>{" "}
              exclusiva do TikTok!
            </p>
          </div>

          {/* Amount */}
          <div className="text-center mb-6">
            <p className="text-gray-500 text-sm">Ganhe até</p>
            <p className="text-4xl font-bold text-gray-900">R$ 2.000,00</p>
            <p className="text-gray-500 text-sm">agora mesmo!</p>
          </div>

          {/* CTA Button */}
          <button
            onClick={handleResgate}
            className="w-full bg-gray-900 text-white py-4 rounded-lg font-semibold flex items-center justify-center gap-2 hover:bg-gray-800 transition-colors"
          >
            🎁 Resgate agora
          </button>

          {/* Timer */}
          <div className="text-center mt-6">
            <p className="text-3xl font-bold text-gray-900">{formatTime(timeLeft)}</p>
            <p className="text-gray-500 text-sm mt-2">
              Responda dentro do tempo e libere sua recompensa. Caso o prazo acabe,{" "}
              <span className="text-red-500">a premiação será encerrada.</span>
            </p>
          </div>
        </div>

        {/* Official Site Badge */}
        <div className="bg-white rounded-lg w-full max-w-md p-4 mt-4 flex items-start gap-3">
          <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0">
            <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
            </svg>
          </div>
          <div>
            <p className="font-semibold text-gray-900">Site oficial de resgate TikTok</p>
            <p className="text-gray-500 text-sm">
              Esta é a plataforma oficial do TikTok. Evite golpes e sites falsos.
              Nunca compartilhe suas senhas com terceiros.
            </p>
          </div>
        </div>

        {/* Footer */}
        <p className="text-gray-500 text-sm mt-8">© 2025 — TikTok</p>
      </main>
    </div>
  );
};

export default Home;
