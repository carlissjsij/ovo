import { useState } from "react";
import { useNavigate } from "react-router-dom";
import tiktokLogo from "@/assets/tiktok-logo-white.svg";
import { Progress } from "@/components/ui/progress";

const questions = [
  {
    question: "Qual é o nome da rede social que você está usando?",
    options: ["Instagram", "TikTok", "Facebook", "Twitter"],
    correct: 1,
  },
  {
    question: "Qual funcionalidade permite gravar vídeos curtos?",
    options: ["Stories", "Reels", "Dueto", "Todas anteriores"],
    correct: 3,
  },
  {
    question: "Quantos segundos pode ter um vídeo curto no TikTok?",
    options: ["15 segundos", "60 segundos", "3 minutos", "Todas anteriores"],
    correct: 3,
  },
  {
    question: "Qual é o símbolo do TikTok?",
    options: ["Coração", "Nota musical", "Câmera", "Estrela"],
    correct: 1,
  },
  {
    question: "O que significa 'FYP' no TikTok?",
    options: ["Follow Your Page", "For You Page", "Find Your Profile", "First Year Post"],
    correct: 1,
  },
];

const Quiz = () => {
  const navigate = useNavigate();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);

  const progress = ((currentQuestion + 1) / questions.length) * 100;

  const handleSelect = (index: number) => {
    if (isAnswered) return;
    setSelectedOption(index);
    setIsAnswered(true);

    setTimeout(() => {
      if (currentQuestion < questions.length - 1) {
        setCurrentQuestion((prev) => prev + 1);
        setSelectedOption(null);
        setIsAnswered(false);
      } else {
        navigate("/wd");
      }
    }, 1000);
  };

  const getOptionClass = (index: number) => {
    if (!isAnswered) {
      return "bg-white border-gray-200 hover:border-gray-400";
    }
    if (index === questions[currentQuestion].correct) {
      return "bg-green-100 border-green-500";
    }
    if (index === selectedOption && index !== questions[currentQuestion].correct) {
      return "bg-red-100 border-red-500";
    }
    return "bg-white border-gray-200";
  };

  return (
    <div className="min-h-screen bg-black flex flex-col">
      {/* Header */}
      <header className="bg-black py-4 flex justify-center">
        <img src={tiktokLogo} alt="TikTok" className="h-8" />
      </header>

      {/* Progress */}
      <div className="px-4 py-4">
        <div className="max-w-md mx-auto">
          <div className="flex justify-between text-white text-sm mb-2">
            <span>Pergunta {currentQuestion + 1} de {questions.length}</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-2 bg-gray-700" />
        </div>
      </div>

      {/* Question */}
      <main className="flex-1 flex flex-col items-center px-4 pb-8">
        <div className="bg-white rounded-lg w-full max-w-md p-6 shadow-lg">
          <h2 className="text-lg font-semibold text-gray-900 mb-6 text-center">
            {questions[currentQuestion].question}
          </h2>

          <div className="space-y-3">
            {questions[currentQuestion].options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleSelect(index)}
                className={`w-full p-4 rounded-lg border-2 text-left transition-all ${getOptionClass(index)}`}
                disabled={isAnswered}
              >
                <span className="font-medium text-gray-900">{option}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Footer */}
        <p className="text-gray-500 text-sm mt-8">© 2025 — TikTok</p>
      </main>
    </div>
  );
};

export default Quiz;
